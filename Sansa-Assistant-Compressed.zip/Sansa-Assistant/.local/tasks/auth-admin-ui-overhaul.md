# Auth, Admin & UI Overhaul

## What & Why
Replace Replit Auth with a custom JWT-based authentication system that gives the app owner (admin) full control. Add email/password user registration for regular users, an enhanced admin dashboard with site configuration and user management, and UI improvements to the chat interface and theming.

## Done looks like
- **Admin Login**: A separate admin login accessible via the app. Admin credentials stored as environment secrets (ADMIN_USERNAME, ADMIN_PASSWORD). Admin can log in with username/password and access a powerful dashboard.
- **User Registration & Login**: Regular users sign up with their name, email, and password. Password is hashed with bcrypt. Users log in with email/password. JWT tokens with 24h expiry handle session management.
- **Personalized Greeting**: The welcome page shows the logged-in user's own first name (e.g., "Good to see you, Priya") — no hardcoded names.
- **Admin Dashboard Enhancements**:
  - View and manage all users (grant/revoke "special" role for enhanced AI access)
  - Edit system prompt, welcome message, and theme config — changes apply immediately for all users
  - View all conversations and platform stats
  - A "Site Config" section where admin can update the AI system prompt, welcome text, and primary color
- **Special Access Role**: Admin can grant "special" role to selected users, giving them enhanced AI capabilities (deeper analysis, advanced templates)
- **UI Improvements**:
  - Chat input box background changed from current secondary color to dark gray
  - Theme-based text colors work correctly (dark mode = white text, light mode = black text)
  - Clean, modern, responsive design maintained
  - User's profile shows their actual name in the sidebar
- **Security**: Passwords hashed with bcrypt, JWT tokens for auth, admin-only middleware for protected routes, CSRF-safe cookie-based sessions

## Out of scope
- Google/Apple OAuth (can be added later as an enhancement)
- Real-time code editor in admin panel (admin edits config/prompts, not raw source code)
- Two-factor authentication
- Password reset via email (users contact admin for now)

## Tasks
1. **Replace auth system** — Remove Replit Auth (OIDC) and implement custom JWT-based auth with bcrypt password hashing. Create register and login API endpoints. Update the users table schema to store hashed passwords. Store admin credentials as environment secrets.

2. **Build login & registration pages** — Create a login page and a registration page in the frontend with email/password fields and name input. Style them to match the app's dark/modern theme. Handle JWT token storage in localStorage and auto-redirect.

3. **Update auth middleware & session management** — Replace OIDC session middleware with JWT verification middleware. Update all existing API routes that check authentication to use the new JWT system. Ensure conversation ownership works with the new user IDs.

4. **Enhance admin dashboard** — Add a "Site Config" page where admin can edit the system prompt, welcome message, and theme colors. Add user role management (grant/revoke "special" access). Store editable config in a new database table so changes persist and apply immediately.

5. **Implement special access role** — When admin grants "special" role to a user, the AI system prompt includes enhanced capabilities (advanced analytics, premium templates, deeper analysis). The special role badge shows in the user's profile.

6. **UI theme improvements** — Change chat input background to dark gray. Ensure theme-based text colors (dark mode = white, light mode = black). Remove any hardcoded name references. Show the logged-in user's actual name everywhere (sidebar, welcome page).

7. **Clean up and integrate** — Remove all Replit Auth dependencies and unused OIDC code. Update the sidebar login/logout flow to use the new custom auth. Ensure all existing features (chat, documents, image upload, HR mode) continue working with the new auth system.

## Relevant files
- `artifacts/api-server/src/routes/auth.ts`
- `artifacts/api-server/src/middlewares/authMiddleware.ts`
- `artifacts/api-server/src/lib/auth.ts`
- `artifacts/api-server/src/app.ts`
- `artifacts/api-server/src/routes/admin.ts`
- `artifacts/api-server/src/routes/openai/conversations.ts`
- `lib/db/src/schema/auth.ts`
- `lib/replit-auth-web/src/use-auth.ts`
- `artifacts/sansa-ai/src/components/sidebar.tsx`
- `artifacts/sansa-ai/src/pages/welcome.tsx`
- `artifacts/sansa-ai/src/pages/settings.tsx`
- `artifacts/sansa-ai/src/pages/admin/index.tsx`
- `artifacts/sansa-ai/src/pages/admin/users.tsx`
- `artifacts/sansa-ai/src/components/chat-input.tsx`
- `artifacts/sansa-ai/src/components/chat-message.tsx`
- `artifacts/sansa-ai/src/index.css`
- `artifacts/sansa-ai/src/App.tsx`
