# Mobile Responsiveness & Settings Page

## What & Why
The app works on desktop but needs polish for iPhone (iOS Safari). The sidebar currently doesn't work as a proper mobile drawer, chat input can get hidden by the iOS keyboard, and there's no dedicated Settings page — HR Mode and Language are squeezed into the sidebar footer alongside the user account controls.

## Done looks like
- On mobile (< 768px), the sidebar slides in from the left as a full-height drawer with a dark overlay; tapping the overlay closes it
- A hamburger/menu icon in the top-left of the chat area opens the sidebar on mobile
- The chat input bar stays visible and accessible above the iOS keyboard (uses `env(safe-area-inset-bottom)` and `dvh` units)
- Messages scroll correctly on iOS without the viewport jumping when the keyboard appears
- A "Settings" link appears in the sidebar; clicking it navigates to `/settings`
- The Settings page contains: HR Mode toggle, Language selector (English / Tamil), and a Light/Dark/System theme selector
- These controls are removed from the sidebar footer (which then only shows the user account block)
- Settings page is clean and simple — full-width cards, descriptive labels, matching the app's overall design

## Out of scope
- Push notifications or device permissions
- Per-conversation settings
- Font size or accessibility settings (future work)

## Tasks
1. **Mobile sidebar drawer** — Refactor the layout so on small screens the sidebar is hidden by default and slides in as a fixed overlay with a semi-transparent backdrop. Wire the existing `sidebarOpen` store state to this. Add a menu button to the top-left of the main content area on mobile.

2. **iOS keyboard + scroll fixes** — Update the chat container and input bar to use `100dvh`, `safe-area-inset-bottom`, and proper `overscroll-behavior` so the keyboard doesn't push content off-screen on iPhones.

3. **Settings page** — Create `/settings` route with a clean page. Move HR Mode toggle and Language selector out of the sidebar footer into Settings. Add a three-way theme selector (Light / Dark / System) that saves to the app store and applies to the `<html>` element. The sidebar footer should only show the user account block after this.

4. **Sidebar nav link** — Add a "Settings" item with a gear icon to the sidebar navigation (below the conversations list, above the footer account block). Also tighten the sidebar footer spacing now that two controls have moved out.

## Relevant files
- `artifacts/sansa-ai/src/components/sidebar.tsx`
- `artifacts/sansa-ai/src/components/layout.tsx`
- `artifacts/sansa-ai/src/store/use-app-store.ts`
- `artifacts/sansa-ai/src/App.tsx`
- `artifacts/sansa-ai/src/index.css`
- `artifacts/sansa-ai/src/hooks/use-mobile.tsx`
