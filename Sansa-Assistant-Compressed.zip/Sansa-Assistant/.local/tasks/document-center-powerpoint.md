# Document Center & PowerPoint

## What & Why
Two missing pieces from the spec: (1) a Document Center page where users can browse, filter, and re-download all AI-generated documents, and (2) PowerPoint (.pptx) generation via pptxgenjs. Currently documents are generated on-the-fly and lost after the session — there is no way to retrieve a file the AI made earlier.

## Done looks like
- User clicks "Documents" in the sidebar → taken to `/documents` page
- Page shows all previously generated files in a grid/list with title, type badge, date
- Filter tabs at the top: All | PDF | Excel | Word | PPT
- Each card has a "Download" button that regenerates and downloads the file
- "Delete" button removes the record from the list
- When the AI generates a document and the user clicks any download button, the record is automatically saved to the database (no extra step for the user)
- PowerPoint option appears alongside PDF / Excel / Word download buttons
- Downloading as PPT creates a clean single-slide-per-section .pptx file with the SANSA branding on a cover slide

## Out of scope
- Uploading existing documents
- Editing document content after generation
- Sharing documents with other users

## Tasks
1. **DB table for saved documents** — Add a `documents` table to the Drizzle schema with columns: id, userId (nullable for anonymous), conversationId (nullable), title, fileType (pdf/excel/word/ppt), content (the raw AI markdown body used to generate the file), createdAt. Run the migration.

2. **Backend API for documents** — Add `/api/documents` routes: GET (list all for current user, newest first), POST (save a new document record), DELETE /:id (delete owned document). Protect with existing auth middleware.

3. **Auto-save on download + PPT generation** — In `use-document-generator.ts`, after any download completes, POST to `/api/documents` to save the record. Add `downloadPPT` function using pptxgenjs: cover slide with title + SANSA logo text, then one content slide per `##` section, with data tables rendered as proper PPT table objects.

4. **Download buttons updated** — Add PPT button (orange) alongside PDF/Excel/Word buttons in `chat-message.tsx`.

5. **Document Center page** — Create `/documents` route and page. Fetch from `/api/documents`. Render as a responsive card grid (icon + title + type badge + date + download + delete). Add filter tab bar at top. Show empty state when no documents exist. Add "Documents" nav link with a folder icon to the sidebar above the conversations list.

## Relevant files
- `lib/db/src/schema/conversations.ts`
- `lib/db/src/schema/index.ts`
- `artifacts/api-server/src/routes/index.ts`
- `artifacts/api-server/src/routes/openai/conversations.ts`
- `artifacts/api-server/src/middlewares/authMiddleware.ts`
- `artifacts/sansa-ai/src/hooks/use-document-generator.ts`
- `artifacts/sansa-ai/src/components/chat-message.tsx`
- `artifacts/sansa-ai/src/components/sidebar.tsx`
- `artifacts/sansa-ai/src/App.tsx`
