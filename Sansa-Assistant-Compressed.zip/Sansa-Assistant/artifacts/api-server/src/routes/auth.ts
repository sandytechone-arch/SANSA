import { Router, type IRouter, type Request, type Response } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  signToken,
  setTokenCookie,
  clearTokenCookie,
} from "../lib/auth";

const router: IRouter = Router();

const ADMIN_USERNAME = process.env.ADMIN_USERNAME;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

if (!ADMIN_USERNAME || !ADMIN_PASSWORD) {
  console.warn("WARNING: ADMIN_USERNAME and/or ADMIN_PASSWORD not set. Admin login will be disabled.");
}

router.get("/auth/user", (req: Request, res: Response) => {
  res.json({
    user: req.isAuthenticated() ? req.user : null,
  });
});

router.post("/auth/register", async (req: Request, res: Response) => {
  try {
    const { email, password, firstName, lastName } = req.body;

    if (!email || !password || !firstName) {
      res.status(400).json({ error: "Email, password, and first name are required" });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ error: "Password must be at least 6 characters" });
      return;
    }

    if (email.endsWith("@sansa-admin")) {
      res.status(400).json({ error: "This email domain is reserved" });
      return;
    }

    const [existing] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, email));

    if (existing) {
      res.status(409).json({ error: "An account with this email already exists" });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const [user] = await db
      .insert(usersTable)
      .values({
        email,
        firstName,
        lastName: lastName || null,
        passwordHash,
        role: "user",
      })
      .returning();

    const authUser = {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      profileImageUrl: user.profileImageUrl,
      role: user.role,
    };

    const token = signToken(authUser);
    setTokenCookie(res, token);

    res.json({ user: authUser });
  } catch (err) {
    console.error("Registration error:", err);
    res.status(500).json({ error: "Registration failed" });
  }
});

router.post("/auth/login", async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: "Email and password are required" });
      return;
    }

    if (email.endsWith("@sansa-admin")) {
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }

    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, email));

    if (!user || !user.passwordHash) {
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }

    const authUser = {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      profileImageUrl: user.profileImageUrl,
      role: user.role,
    };

    const token = signToken(authUser);
    setTokenCookie(res, token);

    res.json({ user: authUser });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Login failed" });
  }
});

router.post("/auth/admin-login", async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;

    if (!ADMIN_USERNAME || !ADMIN_PASSWORD) {
      res.status(503).json({ error: "Admin login is not configured" });
      return;
    }

    if (!username || !password) {
      res.status(400).json({ error: "Username and password are required" });
      return;
    }

    if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
      res.status(401).json({ error: "Invalid admin credentials" });
      return;
    }

    const adminEmail = `${ADMIN_USERNAME}@sansa-admin`;
    const adminPasswordHash = await bcrypt.hash(password, 12);

    let [adminUser] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.email, adminEmail));

    if (!adminUser) {
      [adminUser] = await db
        .insert(usersTable)
        .values({
          email: adminEmail,
          firstName: "Admin",
          lastName: null,
          passwordHash: adminPasswordHash,
          role: "admin",
        })
        .returning();
    } else {
      [adminUser] = await db
        .update(usersTable)
        .set({ role: "admin", passwordHash: adminPasswordHash })
        .where(eq(usersTable.id, adminUser.id))
        .returning();
    }

    const authUser = {
      id: adminUser.id,
      email: adminUser.email,
      firstName: adminUser.firstName,
      lastName: adminUser.lastName,
      profileImageUrl: adminUser.profileImageUrl,
      role: adminUser.role,
    };

    const token = signToken(authUser);
    setTokenCookie(res, token);

    res.json({ user: authUser });
  } catch (err) {
    console.error("Admin login error:", err);
    res.status(500).json({ error: "Admin login failed" });
  }
});

router.post("/auth/logout", (_req: Request, res: Response) => {
  clearTokenCookie(res);
  res.json({ success: true });
});

export default router;
