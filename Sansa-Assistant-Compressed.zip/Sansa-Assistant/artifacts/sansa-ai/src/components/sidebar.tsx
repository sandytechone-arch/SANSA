import { useState, useMemo } from "react";
import { Link, useLocation } from "wouter";
import { Plus, MessageSquare, Trash2, Settings, LogIn, LogOut, User, Folder, Search, X, Pencil, Check, Shield, Sparkles } from "lucide-react";
import sansaLogo from "@/assets/sansa-logo.png";
import { useListOpenaiConversations, useDeleteOpenaiConversation } from "@workspace/api-client-react";
import { useAuth } from "@workspace/replit-auth-web";
import { useQueryClient } from "@tanstack/react-query";
import { useAppStore } from "@/store/use-app-store";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function Sidebar() {
  const [location, setLocation] = useLocation();
  const { data: conversations, isLoading } = useListOpenaiConversations();
  const deleteMutation = useDeleteOpenaiConversation();
  const queryClient = useQueryClient();
  const { setSidebarOpen } = useAppStore();
  const { user, isLoading: authLoading, isAuthenticated, logout } = useAuth();

  const [searchQuery, setSearchQuery] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const filteredConversations = useMemo(() => {
    if (!conversations) return [];
    if (!searchQuery.trim()) return conversations;
    const q = searchQuery.toLowerCase();
    return conversations.filter((c: any) =>
      (c.title || "").toLowerCase().includes(q)
    );
  }, [conversations, searchQuery]);

  const handleNewChat = () => {
    setLocation("/");
    setSidebarOpen(false);
  };

  const handleDelete = async (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm("Delete this conversation?")) {
      await deleteMutation.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: ["/api/openai/conversations"] });
      if (location === `/c/${id}`) {
        setLocation("/");
      }
    }
  };

  const startRename = (e: React.MouseEvent, id: number, currentTitle: string) => {
    e.preventDefault();
    e.stopPropagation();
    setEditingId(id);
    setEditTitle(currentTitle || "");
  };

  const saveRename = async (id: number) => {
    if (!editTitle.trim()) {
      setEditingId(null);
      return;
    }
    try {
      const res = await fetch(`/api/openai/conversations/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ title: editTitle.trim() }),
      });
      if (!res.ok) {
        console.error("Rename failed:", res.status);
        return;
      }
      queryClient.invalidateQueries({ queryKey: ["/api/openai/conversations"] });
    } catch (err) {
      console.error("Failed to rename:", err);
    } finally {
      setEditingId(null);
    }
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/login");
  };

  const isSettingsActive = location === "/settings";

  const displayName = user?.firstName
    ? `${user.firstName}${user.lastName ? ` ${user.lastName}` : ""}`
    : user?.email ?? "User";

  return (
    <div className="flex flex-col h-full overflow-hidden text-sidebar-foreground">
      <div className="px-5 py-4 flex items-center">
        <img
          src={sansaLogo}
          alt="SaNsa"
          className="h-9 w-auto object-contain rounded-lg"
        />
      </div>

      <div className="px-4 pb-3">
        <button
          onClick={handleNewChat}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white text-black hover:bg-gray-100 rounded-xl font-semibold transition-all duration-200 shadow-md active:scale-[0.98]"
        >
          <Plus className="w-5 h-5" />
          <span>New Chat</span>
        </button>
      </div>

      <div className="px-4 pb-2">
        <Link
          href="/documents"
          onClick={() => setSidebarOpen(false)}
          className={cn(
            "flex items-center gap-2.5 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200",
            location === "/documents"
              ? "bg-sidebar-accent text-sidebar-foreground shadow-sm"
              : "hover:bg-sidebar-accent/50 text-sidebar-foreground/70 hover:text-sidebar-foreground"
          )}
        >
          <Folder className={cn("w-4 h-4", location === "/documents" ? "text-primary" : "text-sidebar-foreground/50")} />
          <span>Documents</span>
        </Link>
      </div>

      <div className="px-4 pb-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-sidebar-foreground/40" />
          <input
            type="text"
            placeholder="Search chats..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-8 py-2 text-sm bg-sidebar-accent/50 border border-sidebar-border rounded-xl text-sidebar-foreground placeholder:text-sidebar-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary/30"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 hover:bg-sidebar-accent rounded"
            >
              <X className="w-3 h-3 text-sidebar-foreground/50" />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-3 space-y-1 py-2 custom-scrollbar">
        <div className="px-3 text-xs font-semibold text-sidebar-foreground/50 uppercase tracking-wider mb-2 mt-1">
          Recent
        </div>

        {isLoading ? (
          <div className="space-y-2 px-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-10 bg-sidebar-accent/50 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : filteredConversations.length === 0 ? (
          <div className="px-4 py-8 text-center text-sm text-sidebar-foreground/50">
            {searchQuery ? "No matching conversations." : "No conversations yet."}
          </div>
        ) : (
          filteredConversations.map((conv: any) => {
            const isActive = location === `/c/${conv.id}`;
            const isEditing = editingId === conv.id;
            return (
              <div key={conv.id}>
                {isEditing ? (
                  <div className="flex items-center gap-1 px-2 py-1.5">
                    <input
                      autoFocus
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") saveRename(conv.id);
                        if (e.key === "Escape") setEditingId(null);
                      }}
                      className="flex-1 text-sm bg-sidebar-accent border border-primary/30 rounded-lg px-2 py-1.5 text-sidebar-foreground focus:outline-none focus:ring-1 focus:ring-primary/50"
                    />
                    <button
                      onClick={() => saveRename(conv.id)}
                      className="p-1.5 hover:bg-green-500/20 text-green-500 rounded-md transition-colors"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      className="p-1.5 hover:bg-destructive/20 text-muted-foreground rounded-md transition-colors"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <Link
                    href={`/c/${conv.id}`}
                    onClick={() => setSidebarOpen(false)}
                    className={cn(
                      "group flex items-center justify-between px-3 py-2.5 rounded-xl transition-all duration-200 cursor-pointer",
                      isActive
                        ? "bg-sidebar-accent text-sidebar-foreground shadow-sm"
                        : "hover:bg-sidebar-accent/50 text-sidebar-foreground/80 hover:text-sidebar-foreground"
                    )}
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                      <MessageSquare className={cn("w-4 h-4 shrink-0", isActive ? "text-primary" : "text-sidebar-foreground/50")} />
                      <span className="truncate text-sm font-medium">{conv.title || "New Conversation"}</span>
                    </div>
                    <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-all shrink-0">
                      <button
                        onClick={(e) => startRename(e, conv.id, conv.title || "")}
                        className="p-1.5 hover:bg-secondary rounded-md transition-all"
                        aria-label="Rename chat"
                      >
                        <Pencil className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => handleDelete(e, conv.id)}
                        className="p-1.5 hover:bg-destructive/20 hover:text-destructive rounded-md transition-all"
                        aria-label="Delete chat"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </Link>
                )}
              </div>
            );
          })
        )}
      </div>

      <div className="px-3 pb-2">
        <Link
          href="/settings"
          onClick={() => setSidebarOpen(false)}
          className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 cursor-pointer",
            isSettingsActive
              ? "bg-sidebar-accent text-sidebar-foreground shadow-sm"
              : "hover:bg-sidebar-accent/50 text-sidebar-foreground/70 hover:text-sidebar-foreground"
          )}
        >
          <Settings className={cn("w-4 h-4 shrink-0", isSettingsActive ? "text-primary" : "text-sidebar-foreground/50")} />
          <span className="text-sm font-medium">Settings</span>
        </Link>
      </div>

      <div className="p-4 pt-2 border-t border-sidebar-border bg-sidebar/50">
        {authLoading ? (
          <div className="h-12 bg-sidebar-accent/50 rounded-xl animate-pulse" />
        ) : isAuthenticated && user ? (
          <div className="flex items-center justify-between p-3 rounded-xl bg-sidebar-accent/50 border border-sidebar-border">
            <div className="flex items-center gap-3 overflow-hidden">
              {user.profileImageUrl ? (
                <img
                  src={user.profileImageUrl}
                  alt={user.firstName ?? "User"}
                  className="w-8 h-8 rounded-full object-cover shrink-0"
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                  <User className="w-4 h-4 text-primary" />
                </div>
              )}
              <div className="flex flex-col overflow-hidden">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-medium text-sidebar-foreground truncate">
                    {displayName}
                  </span>
                  {user.role === "admin" && (
                    <Shield className="w-3 h-3 text-violet-400 shrink-0" />
                  )}
                  {user.role === "special" && (
                    <Sparkles className="w-3 h-3 text-amber-400 shrink-0" />
                  )}
                </div>
                <span className="text-[10px] text-sidebar-foreground/60 truncate">{user.email}</span>
              </div>
            </div>
            <button
              onClick={handleLogout}
              title="Log out"
              className="p-1.5 hover:bg-destructive/20 hover:text-destructive rounded-md transition-all shrink-0"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <Link
            href="/login"
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-primary/20 text-primary hover:bg-primary/30 rounded-xl font-semibold transition-all duration-200 border border-primary/30 active:scale-[0.98]"
          >
            <LogIn className="w-4 h-4" />
            <span>Log in to save chats</span>
          </Link>
        )}
      </div>
    </div>
  );
}
